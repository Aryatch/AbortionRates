module com.example.abortionrates {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.abortionrates to javafx.fxml;
    exports com.example.abortionrates;
}