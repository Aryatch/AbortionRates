package com.example.abortionrates;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DBUtility {
    public static ResultSet getAbortionRates() throws Exception {
        String url = "jdbc:mysql://localhost:3306/abortion_data";
        String user = "root";
        String password = "";

        Connection conn = DriverManager.getConnection(url, user, password);
        Statement stmt = conn.createStatement();
        String query = "SELECT age_group, year, abortion_rate FROM abortion_rates";

        return stmt.executeQuery(query);
    }
}