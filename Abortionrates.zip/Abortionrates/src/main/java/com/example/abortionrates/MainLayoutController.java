package com.example.abortionrates;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.sql.ResultSet;

public class MainLayoutController {
    @FXML
    private TableView<AbortionRate> tableView;

    @FXML
    private TableColumn<AbortionRate, String> ageGroupColumn;

    @FXML
    private TableColumn<AbortionRate, Integer> yearColumn;

    @FXML
    private TableColumn<AbortionRate, Double> rateColumn;

    @FXML
    public void initialize() {
        ageGroupColumn.setCellValueFactory(new PropertyValueFactory<>("ageGroup"));
        yearColumn.setCellValueFactory(new PropertyValueFactory<>("year"));
        rateColumn.setCellValueFactory(new PropertyValueFactory<>("rate"));

        try {
            ObservableList<AbortionRate> data = FXCollections.observableArrayList();
            ResultSet rs = DBUtility.getAbortionRates();
            while (rs.next()) {
                data.add(new AbortionRate(rs.getString("age_group"), rs.getInt("year"), rs.getDouble("abortion_rate")));
            }
            tableView.setItems(data);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void showBarChart() {
        try {
            Stage stage = (Stage) tableView.getScene().getWindow();
            Scene scene = new Scene(FXMLLoader.load(getClass().getResource("/com/example/abortionrates/BarChartLayout.fxml")));
            scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
