package com.example.abortionrates;

import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

import java.sql.ResultSet;

public class BarChartLayoutController {

    @FXML
    private BarChart<String, Number> barChart;

    @FXML
    private CategoryAxis xAxis;

    @FXML
    private NumberAxis yAxis;

    @FXML
    public void initialize() {
        XYChart.Series<String, Number> youthSeries = new XYChart.Series<>();
        youthSeries.setName("Youth");

        XYChart.Series<String, Number> adultSeries = new XYChart.Series<>();
        adultSeries.setName("Adult");

        XYChart.Series<String, Number> oldSeries = new XYChart.Series<>();
        oldSeries.setName("Old");

        try {
            ResultSet rs = DBUtility.getAbortionRates();
            while (rs.next()) {
                String ageGroup = rs.getString("age_group");
                int year = rs.getInt("year");
                double rate = rs.getDouble("abortion_rate");
                XYChart.Data<String, Number> data = new XYChart.Data<>(String.valueOf(year), rate);

                switch (ageGroup) {
                    case "Youth":
                        youthSeries.getData().add(data);
                        break;
                    case "Adult":
                        adultSeries.getData().add(data);
                        break;
                    case "Old":
                        oldSeries.getData().add(data);
                        break;
                }

                // Add a style class to the data point based on age group
                data.nodeProperty().addListener((obs, oldNode, newNode) -> {
                    if (newNode != null) {
                        newNode.getStyleClass().add("chart-bar-" + ageGroup.toLowerCase());
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        barChart.getData().addAll(youthSeries, adultSeries, oldSeries);

        // Set axis labels
        xAxis.setLabel("Year");
        yAxis.setLabel("Abortion Rate");
    }

    @FXML
    private void showTableView() {
        // Implement the method to switch to table view as per your requirements
    }
}
