//Name: Rahul Hamal
//ID: 200574082
//Assignment1

package com.example.abortionrates;

public class AbortionRate {
    private String ageGroup;
    private int year;
    private double rate;

    public AbortionRate(String ageGroup, int year, double rate) {
        this.ageGroup = ageGroup;
        this.year = year;
        this.rate = rate;
    }

    public String getAgeGroup() {
        return ageGroup;
    }

    public void setAgeGroup(String ageGroup) {
        this.ageGroup = ageGroup;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }
}
