I've developed a Java application aimed at analyzing abortion rates based on age group and year.
This tool leverages JavaFX for building the user interface and connects directly to a MySQL database named `abortion_data` through JDBC.
The heart of the application lies in the `AbortionRate` class, which encapsulates data attributes like age group, year, and abortion rate.
Using the `DBUtility` class, the application fetches detailed statistics from the `abortion_rates` table, including age group demographics and corresponding abortion rates over the years.
The graphical representation is handled by `BarChartLayoutController`, where a dynamic bar chart visualizes trends for Youth, Adult, and Old age groups from 2015 to 2023.
Each age group is uniquely color-coded for clarity, enhancing the visual impact and making it easier to discern trends at a glance.
For a more detailed examination, the `MainLayoutController` presents the same data in a structured table format using JavaFX's `TableView`, allowing users to explore specific details like age group, year, and abortion rate.
This application provides a seamless experience for users to switch between graphical insights and detailed tabular data, facilitating comprehensive analysis and understanding of abortion rate trends.
